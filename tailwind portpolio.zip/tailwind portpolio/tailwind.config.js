/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./dist/*.html"],
  theme: {
    extend: {
      colors: {
        "regal-blue": "#243c5a",
        "gr-cl": "linear-gradient(to left top, #11998e, #38ef7d)",
      },
    },
    plugins: [],
  },
};
